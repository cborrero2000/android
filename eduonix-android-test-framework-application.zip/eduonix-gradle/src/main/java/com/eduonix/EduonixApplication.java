package com.eduonix;

import android.app.Application;

public class EduonixApplication extends Application {

}
