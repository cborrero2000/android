package com.example.projectone;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by carlos on 2014-11-27.
 */
public class SimpleCalendarActivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }



}
