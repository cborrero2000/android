package com.example.projectone;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

/**
 * Created by carlos on 2014-11-27.
 */
public class FormActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form);
        getActionBar().setHomeButtonEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.form_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch(item.getItemId()){
            case android.R.id.home:
                Intent iHome = new Intent(this, SplashScreen.class);
                startActivity(iHome);
                finish();
                break;

            case R.id.calendar:
                Intent iCalendar = new Intent(this, SimpleCalendarActivity.class);
                startActivity(iCalendar);
                finish();
                break;

            default:
                break;
        }
        return true;
    }

}
